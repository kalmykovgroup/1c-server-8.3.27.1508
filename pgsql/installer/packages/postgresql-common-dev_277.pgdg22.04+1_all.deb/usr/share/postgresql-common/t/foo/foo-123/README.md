The PostgreSQL foo extension
============================

This extension exists for testing postgresql-common's `dh_make_pgxs` and
`dh --with pgxs` mechanisms.
